if [ ! -f /data/data/com.termux.kotlin/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.termux.kotlin/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.termux.kotlin/files/home/.termux
	cp /data/data/com.termux.kotlin/files/usr/share/examples/termux/termux.properties /data/data/com.termux.kotlin/files/home/.termux/
fi
