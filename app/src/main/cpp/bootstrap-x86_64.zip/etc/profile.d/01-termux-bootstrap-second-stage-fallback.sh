#!/data/data/com.termux.kotlin/files/usr/bin/sh
# shellcheck shell=sh

(
# If termux bootstrap second stage has never been run, like in case
# bootstrap was extracted to rootfs from a shell instead of by the
# by the Termux app, which normally runs the second stage, then run it.
# Run silently to not pollute the terminal with installation messages.
if [ ! -L "/data/data/com.termux.kotlin/files/usr/etc/termux/termux-bootstrap/second-stage/termux-bootstrap-second-stage.sh.lock" ]; then
"/data/data/com.termux.kotlin/files/usr/etc/termux/termux-bootstrap/second-stage/termux-bootstrap-second-stage.sh" || exit $?
/files/usr/etc/termux/termux-bootstrap/second-stage/termux-bootstrap-second-stage.sh" > /dev/null 2>&1 || exit $?
fi

# Delete script itself so that it is never run again
rm -f "/data/data/com.termux.kotlin/files/usr/etc/profile.d/01-termux-bootstrap-second-stage-fallback.sh" || exit $?

) || return $?
